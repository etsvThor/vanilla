<?php
/**
 * @author Richard Flynn <richard.flynn@vanillaforums.com>
 * @copyright 2009-2020 Vanilla Forums Inc.
 * @license GPL-2.0-only
 */
// phpcs:ignoreFile

$Definition['Don\'t use too many reactions.'] = 'Don\'t use too many reactions. You don\'t want to give your users information overload.';
$Definition['Which reactions you use really depends on your community.'] =
    'Which reactions you use really depends on your community, but we recommend keeping a couple of points in mind.';
