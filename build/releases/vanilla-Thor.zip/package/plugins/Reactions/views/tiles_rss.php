<?php if (!defined('APPLICATION')) exit();
include $this->fetchViewLocation('DataList', '', 'plugins/Reactions');
