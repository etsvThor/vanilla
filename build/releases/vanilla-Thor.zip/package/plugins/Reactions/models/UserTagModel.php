<?php
/**
 * @copyright 2009-2019 Vanilla Forums Inc.
 * @license Proprietary
 */

/**
 * Class UserTag
 */
class UserTag extends Gdn_Model {
}
