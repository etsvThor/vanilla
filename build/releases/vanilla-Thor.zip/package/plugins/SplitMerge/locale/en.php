<?php
/**
 * @author Richard Flynn <richard.flynn@vanillaforums.com>
 * @copyright 2009-2020 Vanilla Forums Inc.
 * @license GPL-2.0-only
 */
// phpcs:ignoreFile

$Definition['Split %s to new discussion'] = 'You have chosen to split %s into a new discussion.';
