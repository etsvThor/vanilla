jQuery(document).ready(function($) {
    $('pre').addClass('prettyprint linenums');
    if (typeof prettyPrint == 'function')
        prettyPrint();
});
