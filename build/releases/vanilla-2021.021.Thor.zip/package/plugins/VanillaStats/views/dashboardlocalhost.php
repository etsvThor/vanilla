<?php if (!defined('APPLICATION')) exit();
helpAsset(t('Need More Help?'), anchor(t('Using Vanilla Stats on localhost'), 'http://docs.vanillaforums.com/addons/statistics/'));
?>
<div class="Messages Errors">
    <ul>
        <li><?php echo t('Vanilla statistics are disabled on localhost.'); ?></li>
    </ul>
</div>
