<li class="CaptchaInput">
    <?php
    echo $this->Form->label("Security Check", '');
    echo $this->Form->captcha();
?></li>