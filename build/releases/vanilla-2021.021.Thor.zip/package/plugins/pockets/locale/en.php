<?php
/**
 * @copyright 2009-2019 Vanilla Forums Inc.
 * @license GPL-2.0-only
 */

if (!defined('APPLICATION')) {
    exit();
}

$Definition['ValidateIntegerArray'] = '%s must be a comma-delimited list of numbers.';
$Definition['Pockets.BetweenDiscussions.Description'] =
    'The pocket is displayed between each discussion on the main discussion list. ' .
    'Since discussions are usually in &lt;li&gt;..&lt;/li&gt; tags, you\'ll need to wrap your pocket in those tags too.';
$Definition['Show all possible pocket locations.'] =
    'Turn this option on to show all possible pocket locations. Turning on this option will only show the locations to users that can manage pockets.';
