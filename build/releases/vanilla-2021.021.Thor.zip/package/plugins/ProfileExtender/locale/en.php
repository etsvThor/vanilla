<?php
/**
 * @author Richard Flynn <richard.flynn@vanillaforums.com>
 * @copyright 2009-2020 Vanilla Forums Inc.
 * @license GPL-2.0-only
 */
// phpcs:ignoreFile

$Definition['Profile.No'] = 'No';
$Definition['Profile.Yes'] = 'Yes';
